package gaspump.abstractfactory;

import gaspump.datastore.Data;
import gaspump.datastore.Data1;
import strategy.cancelmsg.CancelMsg;
import strategy.displaymenu.DisplayMenu;
import strategy.gaspumpedmsg.GasPumpedMsg;
import strategy.paymsg.PayMsg;
import strategy.printreceipt.PrintReceipt;
import strategy.pumpgasunit.PumpGasUnit;
import strategy.readymsg.ReadyMsg;
import strategy.rejectmsg.RejectMsg;
import strategy.returncash.ReturnCash;
import strategy.setinitialvalues.SetInitialValues;
import strategy.setprice.SetPrice;
import strategy.stopmsg.StopMsg;
import strategy.storecash.StoreCash;
import strategy.storedata.StoreData;
import gaspump.datastore.Data2;
import strategy.cancelmsg.CancelMsg2;
import strategy.displaymenu.DisplayMenu2;
import strategy.gaspumpedmsg.GasPumpedMsg2;
import strategy.paymsg.PayMsg2;
import strategy.printreceipt.PrintReceipt2;
import strategy.pumpgasunit.PumpGasUnit2;
import strategy.readymsg.ReadyMsg2;
import strategy.rejectmsg.RejectMsg2;
import strategy.returncash.ReturnCash2;
import strategy.setinitialvalues.SetInitialValues2;
import strategy.setprice.SetPrice2;
import strategy.stopmsg.StopMsg2;
import strategy.storecash.StoreCash2;
import strategy.storedata.StoreData2;

@SuppressWarnings("unused")
public class GasPump2Factory implements AbstractGasPumpFactory {

	public GasPump2Factory() {
		// TODO Auto-generated constructor stub
	}
	
	public Data getData() {
		// TODO Auto-generated method stub
		return new Data1();
	}

	public StoreData getStoreData() {
		// TODO Auto-generated method stub
		return new StoreData2();
	}

	public PayMsg getPayMsg() {
		// TODO Auto-generated method stub
		return new PayMsg2();
	}

	public StoreCash getStoreCash() {
		// TODO Auto-generated method stub
		return new StoreCash2();
	}

	public DisplayMenu getDisplayMenu() {
		// TODO Auto-generated method stub
		return new DisplayMenu2();
	}

	public RejectMsg getRejectMsg() {
		// TODO Auto-generated method stub
		return new RejectMsg2();
	}

	public SetPrice getSetPrice() {
		// TODO Auto-generated method stub
		return new SetPrice2();
	}

	public ReadyMsg getReadyMsg() {
		// TODO Auto-generated method stub
		return new ReadyMsg2();
	}

	public SetInitialValues getSetInitialValues() {
		// TODO Auto-generated method stub
		return new SetInitialValues2();
	}

	public PumpGasUnit getPumpGasUnit() {
		// TODO Auto-generated method stub
		return new PumpGasUnit2();
	}

	public GasPumpedMsg getGasPumpedMsg() {
		// TODO Auto-generated method stub
		return new GasPumpedMsg2();
	}

	public StopMsg getStopMsg() {
		// TODO Auto-generated method stub
		return new StopMsg2();
	}

	public PrintReceipt getPrintReceipt() {
		// TODO Auto-generated method stub
		return new PrintReceipt2();
	}

	public CancelMsg getCancelMsg() {
		// TODO Auto-generated method stub
		return new CancelMsg2();
	}

	public ReturnCash getReturnCash() {
		// TODO Auto-generated method stub
		return new ReturnCash2();
	}

}
