package gaspump.abstractfactory;

import strategy.cancelmsg.CancelMsg;
import strategy.displaymenu.DisplayMenu;
import strategy.gaspumpedmsg.GasPumpedMsg;
import strategy.paymsg.PayMsg;
import strategy.printreceipt.PrintReceipt;
import strategy.pumpgasunit.PumpGasUnit;
import strategy.readymsg.ReadyMsg;
import strategy.rejectmsg.RejectMsg;
import strategy.returncash.ReturnCash;
import strategy.setinitialvalues.SetInitialValues;
import strategy.setprice.SetPrice;
import strategy.stopmsg.StopMsg;
import strategy.storecash.StoreCash;
import strategy.storedata.StoreData;

public interface AbstractGasPumpFactory {

	public StoreData getStoreData();

	public PayMsg getPayMsg();

	public StoreCash getStoreCash();

	public DisplayMenu getDisplayMenu();

	public RejectMsg getRejectMsg();

	public SetPrice getSetPrice();

	public ReadyMsg getReadyMsg();

	public SetInitialValues getSetInitialValues();

	public PumpGasUnit getPumpGasUnit();

	public GasPumpedMsg getGasPumpedMsg();

	public StopMsg getStopMsg();

	public PrintReceipt getPrintReceipt();

	public CancelMsg getCancelMsg();

	public ReturnCash getReturnCash();

}
