package gaspump.abstractfactory;

import gaspump.datastore.Data;
import strategy.cancelmsg.CancelMsg;
import strategy.displaymenu.DisplayMenu;
import strategy.gaspumpedmsg.GasPumpedMsg;
import strategy.paymsg.PayMsg;
import strategy.printreceipt.PrintReceipt;
import strategy.pumpgasunit.PumpGasUnit;
import strategy.readymsg.ReadyMsg;
import strategy.rejectmsg.RejectMsg;
import strategy.returncash.ReturnCash;
import strategy.setinitialvalues.SetInitialValues;
import strategy.setprice.SetPrice;
import strategy.stopmsg.StopMsg;
import strategy.storecash.StoreCash;
import strategy.storedata.StoreData;
import gaspump.datastore.Data1;
import strategy.cancelmsg.CancelMsg1;
import strategy.displaymenu.DisplayMenu1;
import strategy.gaspumpedmsg.GasPumpedMsg1;
import strategy.paymsg.PayMsg1;
import strategy.printreceipt.PrintReceipt1;
import strategy.pumpgasunit.PumpGasUnit1;
import strategy.readymsg.ReadyMsg1;
import strategy.rejectmsg.RejectMsg1;
import strategy.returncash.ReturnCash1;
import strategy.setinitialvalues.SetInitialValues1;
import strategy.setprice.SetPrice1;
import strategy.stopmsg.StopMsg1;
import strategy.storecash.StoreCash1;
import strategy.storedata.StoreData1;

public class GasPump1Factory implements AbstractGasPumpFactory {

	public GasPump1Factory() {
	}

	public Data getData() {
		// TODO Auto-generated method stub
		return new Data1();
	}

	public StoreData getStoreData() {
		// TODO Auto-generated method stub
		return new StoreData1();
	}

	public PayMsg getPayMsg() {
		// TODO Auto-generated method stub
		return new PayMsg1();
	}

	public StoreCash getStoreCash() {
		// TODO Auto-generated method stub
		return new StoreCash1();
	}

	public DisplayMenu getDisplayMenu() {
		// TODO Auto-generated method stub
		return new DisplayMenu1();
	}

	public RejectMsg getRejectMsg() {
		// TODO Auto-generated method stub
		return new RejectMsg1();
	}

	public SetPrice getSetPrice() {
		// TODO Auto-generated method stub
		return new SetPrice1();
	}

	public ReadyMsg getReadyMsg() {
		// TODO Auto-generated method stub
		return new ReadyMsg1();
	}

	public SetInitialValues getSetInitialValues() {
		// TODO Auto-generated method stub
		return new SetInitialValues1();
	}

	public PumpGasUnit getPumpGasUnit() {
		// TODO Auto-generated method stub
		return new PumpGasUnit1();
	}

	public GasPumpedMsg getGasPumpedMsg() {
		// TODO Auto-generated method stub
		return new GasPumpedMsg1();
	}

	public StopMsg getStopMsg() {
		// TODO Auto-generated method stub
		return new StopMsg1();
	}

	public PrintReceipt getPrintReceipt() {
		// TODO Auto-generated method stub
		return new PrintReceipt1();
	}

	public CancelMsg getCancelMsg() {
		// TODO Auto-generated method stub
		return new CancelMsg1();
	}

	public ReturnCash getReturnCash() {
		// TODO Auto-generated method stub
		return new ReturnCash1();
	}

}
