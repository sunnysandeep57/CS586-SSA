package gaspump.datastore;

public interface Data {
	void setTempGasPrices(Object temp_prices[]);

	void setGasPrices();

	void setTempCash(Object tempCash);

	void setCash();

	void setUnitCount(int count);

	void setTotal(Object total);

	void setPrice(int g);

	Object getCash();

	Object getPrice();

	Object getTotal();

	int getCount();

	String getUnits();

	String getMenu();
}
