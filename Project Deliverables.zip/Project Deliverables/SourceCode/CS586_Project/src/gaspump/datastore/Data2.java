package gaspump.datastore;

import gaspump.datastore.Data;

public class Data2 implements Data {

	Integer[] tempGasPrices;
	Integer[] gasPrices;
	Integer cash;
	Integer tempCash;
	int count;
	Integer total;
	Integer price;
	String menu = "1. Regular\n2. Premium\n3. Super";
	String units = "Liters(s)";

	public Data2() {
		// TODO Auto-generated constructor stub
	}

	public void setTempGasPrices(Object[] temp_prices) {
		tempGasPrices = (Integer[]) temp_prices;
	}

	public void setGasPrices() {
		gasPrices = tempGasPrices;
	}

	public void setTempCash(Object tempCash) {
		this.tempCash = (Integer) tempCash;
	}

	public void setCash() {
		this.cash = this.tempCash;
	}

	public void setUnitCount(int count) {
		this.count = count;
	}

	public void setTotal(Object total) {
		this.total = (Integer) total;
	}

	public void setPrice(int g) {
		this.price = gasPrices[g - 1];
	}

	public Object getPrice() {
		return price;
	}

	public String getMenu() {
		return this.menu;
	}

	public Object getTotal() {
		return this.total;
	}

	public int getCount() {
		return this.count;
	}

	public String getUnits() {
		return this.units;
	}

	public Object getCash() {
		return this.cash;
	}

}
