
package gaspump.datastore;

import gaspump.datastore.Data;

public class Data1 implements Data {

	Float[] tempGasPrices;
	Float[] gasPrices;
	int count;
	Float total;
	Float price;
	String menu = "1. Regular\n2. Super";
	String units = "Gallon(s)";

	public Data1() {
		// TODO Auto-generated constructor stub
	}

	public void setTempGasPrices(Object[] temp_prices) {
		tempGasPrices = (Float[]) temp_prices;
	}

	public void setGasPrices() {
		gasPrices = tempGasPrices;
	}

	public void setTempCash(Object tempCash) {
		// TODO Auto-generated method stub
		// DO NOTHING
	}

	public void setCash() {
		// TODO Auto-generated method stub
		// DO NOTHING
	}

	public void setUnitCount(int count) {
		this.count = count;
	}

	public void setTotal(Object total) {
		this.total = (Float) total;
	}

	public void setPrice(int g) {
		this.price = gasPrices[g - 1];
	}

	public Object getPrice() {
		return price;
	}

	public String getMenu() {
		return this.menu;
	}

	public Object getTotal() {
		return this.total;
	}

	public int getCount() {
		return this.count;
	}

	public String getUnits() {
		return this.units;
	}

	public Object getCash() {
		// DO NOTHING
		return null;
	}

}
