package gaspump.list;

import gaspump.abstractfactory.AbstractGasPumpFactory;
import gaspump.abstractfactory.*;
import inputprocessor.*;
import gaspump.datastore.*;
import mdaefsm.*;
import outputprocessor.*;

public class GasPump2 {
	InputProcessor2 ip;
	OutputProcessor op;
	GaspumpMdaEfsm m;
	Data2 d;
	AbstractGasPumpFactory gpf;

	public GasPump2() {
		d = new Data2();
		gpf = new GasPump2Factory();
		op = new OutputProcessor(gpf, d);
		m = new GaspumpMdaEfsm(op);
		ip = new InputProcessor2(m, d);
	}

	public void activate(int a, int b, int c) {
		ip.activate(a, b, c);
	}

	public void start() {
		ip.start();
	}

	public void payCash(int c) {
		ip.payCash(c);
	}

	public void cancel() {
		ip.cancel();
	}

	public void premium() {
		ip.premium();
	}

	public void Super() {
		ip.Super();
	}

	public void regular() {
		ip.regular();
	}

	public void startPump() {
		ip.startPump();
	}

	public void pumpLiter() {
		ip.pumpLiter();
	}

	public void stop() {
		ip.stop();
	}

	public void receipt() {
		ip.receipt();
	}

	public void noReceipt() {
		ip.noReceipt();
	}

}
