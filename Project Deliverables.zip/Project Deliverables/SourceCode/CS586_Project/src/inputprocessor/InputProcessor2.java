package inputprocessor;

import gaspump.datastore.Data;
import mdaefsm.GaspumpMdaEfsm;

public class InputProcessor2 {

	GaspumpMdaEfsm m;
	Data d;

	public InputProcessor2(GaspumpMdaEfsm m, Data d) {
		this.m = m;
		this.d = d;
	}

	public void activate(int a, int b, int c) {
		if ((a > 0) && (b > 0) && (c > 0)) {
			Integer[] temp_prices = { a, b, c };
			d.setTempGasPrices((Object[]) temp_prices);
			m.activate();
		}
	}

	public void start() {
		m.start();
	}

	public void payCash(int c) {
		if (c > 0) {
			d.setTempCash(c);
			m.payType(2);
		}
	}

	public void cancel() {
		m.cancel();
	}

	public void Super() {
		m.selectGas(3);
	}

	public void premium() {
		m.selectGas(2);
	}

	public void regular() {
		m.selectGas(1);
	}

	public void startPump() {
		m.startPump();
	}

	public void pumpLiter() {
		int cash = (Integer) d.getCash();
		int l = d.getCount();
		int price = (Integer) d.getPrice();
		if (cash < (l + 1) * price)
			m.stopPump();
		else
			m.pump();
	}

	public void stop() {
		m.stopPump();
	}

	public void receipt() {
		m.receipt();
	}

	public void noReceipt() {
		m.noReceipt();
	}

}
