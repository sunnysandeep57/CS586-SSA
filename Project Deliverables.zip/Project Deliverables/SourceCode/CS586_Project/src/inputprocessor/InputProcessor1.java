package inputprocessor;

import gaspump.datastore.Data;
import mdaefsm.GaspumpMdaEfsm;

public class InputProcessor1 {

	GaspumpMdaEfsm m;
	Data d;

	public InputProcessor1(GaspumpMdaEfsm m, Data d) {
		this.m = m;
		this.d = d;
	}

	public void activate(float a, float b) {
		if ((a > 0) && (b > 0)) {
			Float[] temp_prices = { a, b };
			d.setTempGasPrices((Object[]) temp_prices);
			m.activate();
		}
	}

	public void start() {
		m.start();
	}

	public void payCredit() {
		m.payType(1);
	}

	public void reject() {
		m.reject();
	}

	public void cancel() {
		m.cancel();
	}

	public void approved() {
		m.approved();
	}

	public void Super() {
		m.selectGas(2);
	}

	public void regular() {
		m.selectGas(1);
	}

	public void startPump() {
		m.startPump();
	}

	public void pumpGallon() {
		m.pump();
	}

	public void stopPump() {
		m.stopPump();
		m.receipt();
	}

}
