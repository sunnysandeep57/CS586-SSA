package strategy.rejectmsg;

import gaspump.datastore.Data;

public interface RejectMsg {
	public void rejectMessage(Data data);
}
