package strategy.pumpgasunit;

import gaspump.datastore.Data;

public interface PumpGasUnit {
	public void pumpGasUnit(Data data);
}
