package strategy.pumpgasunit;

import gaspump.datastore.Data;

public class PumpGasUnit1 implements PumpGasUnit {
	public void pumpGasUnit(Data data) {
		int units = data.getCount();
		// All the input units are of float data type
		Float price = (Float) data.getPrice();
		units++;
		Float total = price * units;
		data.setUnitCount(units);
		data.setTotal(total);
	}
}
