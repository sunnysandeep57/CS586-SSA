package strategy.pumpgasunit;

import gaspump.datastore.Data;

public class PumpGasUnit2 implements PumpGasUnit {
	public void pumpGasUnit(Data data) {
		int units = data.getCount();
		//All the units are of integer data type
		Integer price = (Integer) data.getPrice();
		units++;
		Integer total = price * units;
		data.setUnitCount(units);
		data.setTotal(total);
	}
}
