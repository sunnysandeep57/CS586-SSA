package strategy.readymsg;

import gaspump.datastore.Data;

public interface ReadyMsg {
	public void readyMsg(Data data);
}
