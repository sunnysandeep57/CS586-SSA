package strategy.stopmsg;
import gaspump.datastore.Data;

public interface StopMsg {
	public void stopMsg(Data data);
}
