package strategy.storecash;

import gaspump.datastore.Data;

public interface StoreCash {
	public void storeCash(Data data);
}
