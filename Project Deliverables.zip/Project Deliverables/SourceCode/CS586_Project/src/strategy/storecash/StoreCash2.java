package strategy.storecash;

import gaspump.datastore.Data;

public class StoreCash2 implements StoreCash {
	public void storeCash(Data data) {
		data.setCash();
		//stores the cash
	}
}
