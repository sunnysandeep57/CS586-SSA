package strategy.cancelmsg;

import gaspump.datastore.Data;

public interface CancelMsg {
	public void cancelMessage(Data data);
}
