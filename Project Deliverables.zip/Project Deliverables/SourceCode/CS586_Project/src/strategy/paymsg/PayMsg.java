package strategy.paymsg;

import gaspump.datastore.Data;

public interface PayMsg {
	public void payMessage(Data data);
}
