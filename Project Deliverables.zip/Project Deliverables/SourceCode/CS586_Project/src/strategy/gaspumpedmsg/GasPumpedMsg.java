package strategy.gaspumpedmsg;

import gaspump.datastore.Data;

public interface GasPumpedMsg {
	public void gasPumpedMsg(Data d);
}
