package strategy.printreceipt;

import gaspump.datastore.Data;

public interface PrintReceipt {
	public void printReceipt(Data data);
}
