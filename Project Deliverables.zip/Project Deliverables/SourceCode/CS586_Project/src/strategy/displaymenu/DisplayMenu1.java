
package strategy.displaymenu;
import gaspump.datastore.Data;

public class DisplayMenu1 implements DisplayMenu {
	public void displayMenu(Data data) {
		System.out.println("Select Gasoline Type:");
		System.out.println("A)	Super");
		System.out.println("B)	Regular");
		//System.out.println(data.getMenu());
	}
}
