package strategy.displaymenu;

import gaspump.datastore.Data;

public interface DisplayMenu {
	public void displayMenu(Data data);
}
