package strategy.displaymenu;

import gaspump.datastore.Data;

public class DisplayMenu2 implements DisplayMenu {
	public void displayMenu(Data data) {
		System.out.println("GasPump2 Menu \nSelect Gasoline Type:");
		System.out.println("A)	Premium");
		System.out.println("B)	Regular");
		System.out.println("C)	Super");
		//System.out.println(data.getMenu());
	}
}
