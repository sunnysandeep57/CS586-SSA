package strategy.setprice;

import gaspump.datastore.Data;

public interface SetPrice {
	public void setPrice(Data data, int g);
}
