package strategy.returncash;

import gaspump.datastore.Data;
import strategy.returncash.*;

@SuppressWarnings("unused")
public class ReturnCash1 implements ReturnCash {
	public void returnCash(Data data) {

	}
}
