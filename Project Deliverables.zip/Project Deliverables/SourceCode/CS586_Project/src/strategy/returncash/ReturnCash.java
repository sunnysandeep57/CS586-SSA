package strategy.returncash;

import gaspump.datastore.Data;

public interface ReturnCash {
	public void returnCash(Data data);
}
