package strategy.returncash;
import gaspump.datastore.Data;
import strategy.returncash.*;

@SuppressWarnings("unused")
public class ReturnCash2 implements ReturnCash {
	public void returnCash(Data data) {
		int balance = (Integer) data.getCash() - (Integer) data.getTotal();
		System.out.println("Balance Return : $" + balance);
	}
}
