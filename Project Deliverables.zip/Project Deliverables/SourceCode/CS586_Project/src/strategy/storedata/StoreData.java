package strategy.storedata;

import gaspump.datastore.Data;

public interface StoreData {
	public void storeData(Data data);
}
