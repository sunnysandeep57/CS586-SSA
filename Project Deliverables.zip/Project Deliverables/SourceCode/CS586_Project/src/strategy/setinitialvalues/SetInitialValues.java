package strategy.setinitialvalues;

import gaspump.datastore.Data;

public interface SetInitialValues {
	public void setInitialValues(Data data);
}
