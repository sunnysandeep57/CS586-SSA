package states;

import mdaefsm.GaspumpMdaEfsm;
import outputprocessor.*;

public class S4 extends State {

	public S4(GaspumpMdaEfsm mda, OutputProcessor op) {
		super(mda, op, 5);
		// TODO Auto-generated constructor stub
	}

	public void startPump() {
		op.setInitialValues();
		op.readyMsg();
		mda.changeState(6);
	}

}
