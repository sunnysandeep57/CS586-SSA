package states;

import mdaefsm.GaspumpMdaEfsm;
import outputprocessor.*;

public class S6 extends State {

	public S6(GaspumpMdaEfsm mda, OutputProcessor op) {
		super(mda, op, 7);

	}

	// Receipt() method
	public void receipt() {
		op.printReceipt();
		op.returnCash();
		mda.changeState(1);
	}

	// noReceipt() method
	public void noReceipt() {
		op.returnCash();
		mda.changeState(1);
	}

}
