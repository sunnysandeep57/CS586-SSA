package states;

import mdaefsm.GaspumpMdaEfsm;
import outputprocessor.*;

public class S1 extends State {

	public S1(GaspumpMdaEfsm mda, OutputProcessor op) {
		super(mda, op, 2);
		// TODO Auto-generated constructor stub
	}

	public void payType(int t) {
		if (t == 1) {
			mda.changeState(3);
		} else if (t == 2) {
			op.storeCash();
			op.displayMenu();
			mda.changeState(4);
		}
	}

}
